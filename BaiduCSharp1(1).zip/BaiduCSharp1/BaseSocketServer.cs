﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

namespace BaiduCSharp1
{
    //用于接收基准站的socket服务端
    class BaseSocketServer : BaiduCSharp1.DeviceSocketServer
    {


         public BaseSocketServer(Form1 form):base(form)
         {
             parentForm = form;
        
         }

        public new void Start()
        {
            try
            {
                IPAddress ipAddress = IPAddress.Parse(INIhelp.GetValue("基准站服务端IP地址"));
                int port = int.Parse(INIhelp.GetValue("基准站服务端端口"));

                //创建监听Socket
                mainSocket = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);

                //邦定IP
                IPEndPoint ipLocal = new IPEndPoint(ipAddress, port);
                mainSocket.Bind(ipLocal);

                //开始监听
                mainSocket.Listen(5);

                //创建Call Back为任意客户端连接
                mainSocket.BeginAccept(new AsyncCallback(OnDeviceConnect), null);

                //创建基准站差分数据缓存区
                byte[] diff_1005 = new byte[1100];
                byte[] diff_1074 = new byte[1100];
                byte[] diff_1124 = new byte[1100];


            }
            catch (SocketException se)
            {
                parentForm.AppendReceivedMsg(se.Message);
            }
        }

        //回调函数，终端设备连接时被调用
        public override void OnDeviceConnect(IAsyncResult asyn)
        {
            try
            {
                // 创建一个新的 Socket 
                Socket workerSocket = mainSocket.EndAccept(asyn);

                // 递增客户端数目
                Interlocked.Increment(ref clientCount);

                // 添加到客户端数组中
                workerSocketList.Add(workerSocket);
                parentForm.AppendReceivedMsg("基准站 " + clientCount.ToString() + " 链接成功");

                //发送一个消息，暂时不用
                //string msg = "Welcome 客户端 " + clientCount + "\n";
                //SendMsgToClient(msg, clientCount);
                //byte[] byData = new byte[] { 0x48, 0x54, 0x00, 0x11, 0x00, 0x01, 0x01, 0x09, 0xFF, 0xFF, 0x07, 0xE5, 0x0C, 0x07, 0x0, 0x09, 0x38, 0x24, 0x2B };
                //byte[] byData = new byte[] { 0x48, 0x54, 0x00, 0x0A, 0x00, 0x01, 0x01, 0x02, 0x07, 0xDC, 0x24, 0x2B };

                //byte[] byData;
                //int lengthByData;

                //parentForm.GetMsgTime(out byData, out lengthByData);

                //Send(workerSocket, byData, byData.Length);

                //刷新已连接的客户端列表,用于更新界面，暂时不用
                //RefreshConnectedClientList();

                //指定这个Socket处理接收到的数据，注意当前socket还没有接到任何数据，还不知道其对应的终端设备ID
                WaitForData(workerSocket, clientCount);
               
                // Main Socket继续等待客户端的连接
                mainSocket.BeginAccept(new AsyncCallback(OnDeviceConnect), null);
            }
            catch (ObjectDisposedException)
            {
                System.Diagnostics.Debugger.Log(0, "1", "\n 客户端连接: Socket 已关闭\n");
            }
            catch (SocketException se)
            {
                parentForm.AppendReceivedMsg(se.Message);
            }
            catch (Exception se)
            {
                parentForm.AppendReceivedMsg(se.Message);
            }
        }


        //Call Back, Socket检测到任意终端设备客户端写入数据时
        public override void OnDataReceived(IAsyncResult asyn)
        {
            SocketPacket socketData = (SocketPacket)asyn.AsyncState;
            string msgTemp;

            try
            {
                int iRx = socketData.currSocket.EndReceive(asyn);
                //System.Diagnostics.Debug.Write("基准站 " + socketData.clientNO + " DataLength:" + iRx.ToString() + "\r\n");
                //char[] chars = new char[iRx + 1];

                //System.Text.Decoder decoder = System.Text.Encoding.UTF8.GetDecoder();
                //int charLen = decoder.GetChars(socketData.dataBuffer, 0, iRx, chars, 0);

                //System.String szData = new System.String(chars);
                //从目前看来，不能捕获客户端主动断开的消息，会进入一个死循环，看看是否可以根据接收到的数据长度为零进行处理
                //现在只能在这里增加一个当接收到的数据长度为0时，发送一条数据给客户端，用于及时检测到客户端断开，
                if (iRx <= 0)
                {
                    //一个电量查询的语句，但是终端编号和校验位都不对
                    byte[] byData = new byte[] { 0x48, 0x54, 0x00, 0x08, 0x00, 0x01, 0x01, 0x23, 0x00, 0x00 };
                    socketData.currSocket.Send(byData);
                }
                else//应该将处理函数放在这里
                {
                    //Send(socketData.currSocket, socketData.dataBuffer, iRx);

                    //解析数据，上传到界面
                    //AppendReceivedMsg( "Client " + socketData.clientNO + " DataLength:" + charLen.ToString());
                    parentForm.AppendReceivedMsg("基准站 " + socketData.clientNO + " DataLength:" + iRx.ToString());
                    
                    //AppendReceivedMsg(Environment.NewLine + "Client " + socketData.clientNO + " Data:" + new System.String(chars));

                    //在这里直接调用socket类进行数据解析，数据量少，不额外增加解析线程
                    Buffer.BlockCopy(socketData.dataBuffer, 0, socketData.parseBuffer, socketData.parseBufferLength, iRx);//将数据放入解析缓冲区
                    socketData.parseBufferLength = socketData.parseBufferLength + iRx;//修改解析缓冲区的数据长度

                    //这里不进行数据处理了，直接转发出去，缓冲区里面的数据清空
                    //parentForm.ReceiveBaseData(socketData.parseBuffer, socketData.parseBufferLength);
                    //socketData.parseBufferLength = 0;//修改解析缓冲区的数据长度

                    //解析RTCM数据，只有1005、1074和1124有用

                    //同步码  保留位    长度    信息类型    信息内容         校验数据
                    //8位      6位       10位    12位         N位             24位
                    //D3       全零       
                     while (socketData.parseBufferLength >= 6)//数据长度至少为6个字节，才够一包数据，进行数据解析
                     {
                         if (socketData.parseBuffer[0] == 0xD3 && (socketData.parseBuffer[1] & 0xFC) == 0x00)//找到消息头
                         {
                             //解析数据长度
                             int nLength = (socketData.parseBuffer[1] & 0x03) * 256 + socketData.parseBuffer[2];//解析数据长度
                             nLength = nLength + 6;

                             if (nLength > socketData.parseBufferLength)//本报数据还没有收全
                                 break;

                             //解析消息类型
                             int msgType = (socketData.parseBuffer[3]) * 16 + (socketData.parseBuffer[4] & 0xF0)/16;

                            //只是处理有用的几条消息
                            switch (msgType)
                            {
                                case 1005://参考站坐标 解析一下参考站ID
                                    uint msg1005length = GetBitU(socketData.parseBuffer, 14, 10);
                                    uint msg1005type = GetBitU(socketData.parseBuffer, 24, 12);
                                    uint ReferenceStationID = GetBitU(socketData.parseBuffer, 36, 12);

                                    msgTemp = "基准站1005消息：站址ID " + ReferenceStationID.ToString() + "\n";
                                    parentForm.AppendReceivedMsg(msgTemp);

                                    System.Diagnostics.Debug.Write(msgTemp);

                                    break;
                                case 1074://GPS MSM4
                                case 1124:
                                    uint bitIndex = 24;//消息长度后的位数 ;
                                    uint msg1074type = GetBitU(socketData.parseBuffer, bitIndex, 12);  bitIndex += 12;//消息类型
                                    uint msg1074RefStaID = GetBitU(socketData.parseBuffer, bitIndex, 12); bitIndex += 12;//参考站ID
                                    bitIndex += 30;//GNSS历元时刻
                                    byte msg1074MulMesBit = (byte)GetBitU(socketData.parseBuffer, bitIndex, 1); bitIndex += 1;//MSM多电文标志
                                    bool msg1074ObsDataIsCom = (msg1074MulMesBit == 0 ? true : false);
                                    bitIndex += 3;//IODS
                                    bitIndex += 7;//保留
                                    bitIndex += 4;//时钟校准，扩展时钟
                                    bitIndex += 4;//平滑类型，平滑区间

                                    uint NSat = 0;//卫星数量
                                    uint msg1074Satmask = 0;
                                    
                                    //System.Diagnostics.Debug.Write("卫星掩码");
                                    for (int i = 1; i <= 64; i++)
                                    {
                                         msg1074Satmask = GetBitU(socketData.parseBuffer, bitIndex, 1); bitIndex += 1;//卫星掩码
                                        if (msg1074Satmask > 0) NSat++;

                                        msgTemp = msg1074Satmask.ToString();
                                       // System.Diagnostics.Debug.Write(msgTemp);
                                    }

                                    uint Nsig = 0;//信号数量
                                    uint msg1074Sigmask =0;
                                    //System.Diagnostics.Debug.Write("信号掩码");
                                    for (int i = 1; i <= 32; i++)
                                    {
                                        msg1074Sigmask = GetBitU(socketData.parseBuffer, bitIndex, 1); bitIndex += 1;//信号掩码
                                        if (msg1074Sigmask > 0) Nsig++;

                                        msgTemp = msg1074Sigmask.ToString();
                                        //System.Diagnostics.Debug.Write(msgTemp);
                                    }

                                    uint NSatNsig = NSat * Nsig;
                                    if (NSatNsig > 64)//异常了，后面再考虑如何处理
                                    {
                                        break;
                                    }

                                    uint NCell = 0;//单元数量
                                    //System.Diagnostics.Debug.Write("单元掩码");
                                    for (int i = 1; i <= NSatNsig; i++)
                                    {
                                        uint msg1074Cellmask = GetBitU(socketData.parseBuffer, bitIndex, 1); bitIndex += 1;//单元掩码
                                        if (msg1074Cellmask > 0) NCell++;

                                        msgTemp = msg1074Cellmask.ToString();
                                        //System.Diagnostics.Debug.Write(msgTemp);
                                    }

                                    msgTemp = "基准站" + msgType.ToString() + 
                                        "消息：站址ID " + msg1074RefStaID.ToString() +
                                        "多电文标志" + msg1074ObsDataIsCom.ToString() +
                                        "卫星数量" + NSat.ToString() + "卫星掩码"+ GetBitU(socketData.parseBuffer, 97, 32).ToString("X") +" " +GetBitU(socketData.parseBuffer, 129, 32).ToString("X") +
                                        "信号数量" + Nsig.ToString() + "信号掩码" + GetBitU(socketData.parseBuffer,161, 32).ToString("X") +
                                        "单元数量" + NCell.ToString() + "单元掩码" + GetBitU(socketData.parseBuffer, 193, Math.Min(NSatNsig,32)).ToString("X");
                                    //parentForm.AppendReceivedMsg(msgTemp);

                                    System.Diagnostics.Debug.Write(msgTemp);

                                    //卫星数据，暂时没啥用，就不解析了
                                    bitIndex += NSat * 18;

                                    //信号数据
                                    bitIndex += NCell * 15;//GNSS信号精确伪距观测值
                                    bitIndex += NCell * 22;//GNSS信号精确相位距离数据
                                    bitIndex += NCell * 4;//GNSS相位距离锁定时间标志
                                    bitIndex += NCell * 1;//半周模糊度指标

                                    double msg1074CNR = 0;
                                    
                                    System.Diagnostics.Debug.Write("信噪比");
                                    for (int i = 0; i < NCell; i++)
                                    {
                                        msg1074CNR = GetBitU(socketData.parseBuffer, bitIndex, 6) * 1.0; bitIndex += 6;
                                        msgTemp = "信噪比" + msg1074CNR.ToString()  + " ";
                                        System.Diagnostics.Debug.Write(msgTemp);
                                    }
                                    System.Diagnostics.Debug.Write( "\n");
                                    break;

                                default://不用做任何处理
                                    break;

                            }

                            //这里不做数据解析，直接将一包数据传递给界面或者终端设备socket，将差分数据发送给所有已连接终端设备
                            //后续可以判断一下是否是一包数据，防止发送给终端的是半包数据
                            //待完成
                            parentForm.ReceiveBaseData(socketData.parseBuffer, nLength);

                             Buffer.BlockCopy(socketData.parseBuffer, nLength, socketData.parseBuffer, 0, socketData.parseBufferLength - nLength);//将解析缓冲区数据向前移动消息长度
                             socketData.parseBufferLength = socketData.parseBufferLength - nLength;//修改解析缓冲区的数据长度
                         }
                         else//消息头不对，向前移动一位
                         {
                             Buffer.BlockCopy(socketData.parseBuffer, 1, socketData.parseBuffer, 0, socketData.parseBufferLength - 1);//将解析缓冲区数据向前移动一位
                             socketData.parseBufferLength = socketData.parseBufferLength - 1;//修改解析缓冲区的数据长度
                         }
                     }




                    //For Debug
                    //string replyMsg = "Server 回复:" + szData.ToUpper();

                    //回复客户端信息，不需要
                    //string replyMsg = "Server 回复: 接收完成";
                    //byte[] byData = System.Text.Encoding.UTF8.GetBytes(replyMsg);

                    //Socket workerSocket = (Socket)socketData.currSocket;
                    //workerSocket.Send(byData);


                    //这个地方对原来的调用进行了优化，原来新创建很多socketData，其实很费资源的
                    //WaitForData(socketData.currSocket, socketData.clientNO);
                    socketData.currSocket.BeginReceive(socketData.dataBuffer, 0, socketData.dataBuffer.Length, SocketFlags.None, pfnWorkerCallBack, socketData);



                }//else


            }//try
            catch (ObjectDisposedException)
            {
                parentForm.AppendReceivedMsg("数据接收时: Socket 已关闭");
            }
            catch (SocketException se)
            {
                if (se.ErrorCode == 10054) // 连接被管道重置
                {
                    //socketData.currSocket.Close();

                    string msg = "基准站 " + socketData.clientNO + " 断开连接" + "\n";
                    parentForm.AppendReceivedMsg(msg);

                    //这个似乎有问题吧，只是将socket设置为空，待垃圾回收？没有关闭相应的socket
                    Socket workerSocket = (Socket)workerSocketList[socketData.clientNO - 1];
                    //workerSocket.Shutdown(SocketShutdown.Both);
                    workerSocket.Close();
                    workerSocket = null;
                    //workerSocketList[socketData.clientNO - 1] = null;
                    //RefreshConnectedClientList();
                }
                else if (se.ErrorCode == 10053)
                {
                    parentForm.AppendReceivedMsg(se.Message);

                    //这个似乎有问题吧，只是将socket设置为空，待垃圾回收？没有关闭相应的socket
                    Socket workerSocket = (Socket)workerSocketList[socketData.clientNO - 1];
                    //workerSocket.Shutdown(SocketShutdown.Both);
                    workerSocket.Close();
                    workerSocket = null;
                    //workerSocketList[socketData.clientNO - 1] = null;
                    //RefreshConnectedClientList();
                }
            }
            catch (Exception se)
            {
                parentForm.AppendReceivedMsg(se.Message);

                //这个似乎有问题吧，只是将socket设置为空，待垃圾回收？没有关闭相应的socket
                Socket workerSocket = (Socket)workerSocketList[socketData.clientNO - 1];
                //workerSocket.Shutdown(SocketShutdown.Both);
                workerSocket.Close();
                workerSocket = null;
                //workerSocketList[socketData.clientNO - 1] = null;
                //RefreshConnectedClientList();
            }
        }

    }
}
